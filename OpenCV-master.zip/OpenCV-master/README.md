# OpenCV

This repo has all basic code snippets needed for computer vision using OpenCV.Eventually it will include projects built using OpenCV.
